export function StatusBadge({ status }) {
  const peta = {
    ONLINE: { kelas: "online", label: "Online" },
    TERHUBUNG: { kelas: "online", label: "Terhubung" },
    OFFLINE: { kelas: "offline", label: "Offline" },
    TERPUTUS: { kelas: "offline", label: "Terputus" },
    MENUNGGU_SCAN: { kelas: "warning", label: "Menunggu Scan" },
    TIDAK_DIKETAHUI: { kelas: "offline", label: "Tidak diketahui" },
    ISOLIR: { kelas: "critical", label: "Isolir" },
    BELUM_BAYAR: { kelas: "warning", label: "Belum bayar" },
    LUNAS: { kelas: "online", label: "Lunas" },
  };

  const info = peta[status] || { kelas: "offline", label: status };

  return (
    <span className={`badge ${info.kelas}`}>
      <span className="badge-dot" />
      {info.label}
    </span>
  );
}
