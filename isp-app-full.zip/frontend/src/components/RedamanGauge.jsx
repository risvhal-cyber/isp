// Rentang umum redaman GPON: -8 s/d -27 dBm dianggap wajar.
// Di bawah -27 kritis, -24 s/d -27 mulai perlu diwaspadai.
function nilaiKeStatus(dbm) {
  if (dbm === null || dbm === undefined) return "offline";
  if (dbm <= -27) return "critical";
  if (dbm <= -24) return "warning";
  return "online";
}

export function RedamanGauge({ dbm }) {
  const status = nilaiKeStatus(dbm);
  // skala visual dari -35 (buruk) sampai -5 (bagus)
  const persen = dbm === null || dbm === undefined ? 0 : Math.min(100, Math.max(0, ((dbm + 35) / 30) * 100));

  const warnaBar = { online: "var(--accent)", warning: "var(--warning)", critical: "var(--critical)", offline: "var(--border)" }[status];

  return (
    <div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 10 }}>
        <span className="mono" style={{ fontSize: 32, fontWeight: 600, color: warnaBar }}>
          {dbm !== null && dbm !== undefined ? dbm.toFixed(1) : "—"}
        </span>
        <span style={{ color: "var(--text-muted)", fontSize: 14 }}>dBm</span>
      </div>
      <div style={{ height: 6, background: "var(--surface-raised)", borderRadius: 999, overflow: "hidden" }}>
        <div style={{ width: `${persen}%`, height: "100%", background: warnaBar, transition: "width 0.4s ease" }} />
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6, fontSize: 11, color: "var(--text-muted)" }}>
        <span>-35 dBm</span>
        <span>-5 dBm</span>
      </div>
    </div>
  );
}
