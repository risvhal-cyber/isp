import { useNavigate } from "react-router-dom";
import { auth } from "../lib/api";

export function Sidebar() {
  const navigate = useNavigate();
  const user = auth.ambilUser();

  function logout() {
    auth.hapusToken();
    navigate("/login");
  }

  return (
    <aside
      style={{
        width: "var(--sidebar-width)",
        flexShrink: 0,
        borderRight: "1px solid var(--border)",
        padding: "24px 18px",
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        position: "sticky",
        top: 0,
      }}
    >
      <div style={{ marginBottom: 36, paddingLeft: 8 }}>
        <div className="mono" style={{ color: "var(--accent)", fontSize: 12, letterSpacing: "0.05em" }}>
          NOC
        </div>
        <h2 style={{ fontSize: 18, marginTop: 2 }}>ISP App</h2>
      </div>

      <nav style={{ display: "flex", flexDirection: "column", gap: 2, flex: 1 }}>
        <ItemNav label="Ringkasan" aktif />
        <ItemNav label="Mikrotik" />
        <ItemNav label="OLT" />
        <ItemNav label="Pelanggan" />
        <ItemNav label="Tagihan" />
        <ItemNav label="WA Gateway" />
      </nav>

      <div style={{ borderTop: "1px solid var(--border)", paddingTop: 16 }}>
        <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 10, paddingLeft: 8 }}>
          {user?.nama} · {user?.role}
        </div>
        <button className="btn btn-ghost" style={{ width: "100%" }} onClick={logout}>
          Keluar
        </button>
      </div>
    </aside>
  );
}

function ItemNav({ label, aktif }) {
  return (
    <div
      style={{
        padding: "9px 12px",
        borderRadius: 8,
        fontSize: 14,
        fontWeight: 500,
        color: aktif ? "var(--text)" : "var(--text-muted)",
        background: aktif ? "var(--surface)" : "transparent",
        cursor: "pointer",
      }}
    >
      {label}
    </div>
  );
}
