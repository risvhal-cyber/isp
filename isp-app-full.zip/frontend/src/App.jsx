import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard";
import PelangganDashboard from "./pages/PelangganDashboard";
import { auth } from "./lib/api";

function RuteTerproteksi({ children, rolesDiizinkan }) {
  const token = auth.ambilToken();
  const user = auth.ambilUser();

  if (!token || !user) return <Navigate to="/login" replace />;
  if (rolesDiizinkan && !rolesDiizinkan.includes(user.role)) return <Navigate to="/login" replace />;

  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/admin"
          element={
            <RuteTerproteksi rolesDiizinkan={["ADMIN", "PENAGIH"]}>
              <AdminDashboard />
            </RuteTerproteksi>
          }
        />
        <Route
          path="/pelanggan"
          element={
            <RuteTerproteksi rolesDiizinkan={["PELANGGAN"]}>
              <PelangganDashboard />
            </RuteTerproteksi>
          }
        />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
