import { useEffect, useState } from "react";
import { Sidebar } from "../components/Sidebar";
import { StatusBadge } from "../components/StatusBadge";
import { api } from "../lib/api";

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .dashboardAdmin()
      .then(setData)
      .catch((err) => setError(err.message));
  }, []);

  return (
    <div style={{ display: "flex" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "32px 40px", maxWidth: 1100 }}>
        <h1 style={{ fontSize: 26, marginBottom: 4 }}>Ringkasan Sistem</h1>
        <p style={{ color: "var(--text-muted)", marginBottom: 28 }}>
          Kondisi jaringan dan pelanggan saat ini.
        </p>

        {error && (
          <div className="card" style={{ borderColor: "var(--critical)", marginBottom: 20 }}>
            Gagal memuat data: {error}. Pastikan backend berjalan di{" "}
            <code className="mono">{import.meta.env.VITE_API_URL || "http://localhost:3000"}</code>.
          </div>
        )}

        {data && (
          <>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))",
                gap: 14,
                marginBottom: 28,
              }}
            >
              <StatCard label="Pelanggan" nilai={data.jumlahPelanggan} />
              <StatCard label="Router Mikrotik" nilai={data.jumlahMikrotik} />
              <StatCard label="OLT" nilai={data.jumlahOlt} />
              <StatCard label="Tagihan belum lunas" nilai={data.tagihanBelumLunas} aksen="warning" />
            </div>

            <h2 style={{ fontSize: 18, marginBottom: 14 }}>Status Router Mikrotik</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {data.statusMikrotik?.length === 0 && (
                <div className="card" style={{ color: "var(--text-muted)" }}>
                  Belum ada router terdaftar.
                </div>
              )}
              {data.statusMikrotik?.map((m) => (
                <div
                  key={m.id}
                  className="card"
                  style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}
                >
                  <div>
                    <div style={{ fontWeight: 600, marginBottom: 4 }}>{m.nama}</div>
                    <div style={{ fontSize: 13, color: "var(--text-muted)" }}>
                      {m.online ? `${m.interfaces?.length ?? 0} interface · uptime ${m.uptime}` : m.error}
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
                    {m.online && (
                      <div className="mono" style={{ fontSize: 13, color: "var(--text-muted)", textAlign: "right" }}>
                        CPU {m.cpuLoad}% 
                      </div>
                    )}
                    <StatusBadge status={m.online ? "ONLINE" : "OFFLINE"} />
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  );
}

function StatCard({ label, nilai, aksen }) {
  return (
    <div className="card">
      <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 8 }}>{label}</div>
      <div
        className="mono"
        style={{ fontSize: 30, fontWeight: 600, color: aksen === "warning" ? "var(--warning)" : "var(--text)" }}
      >
        {nilai ?? "—"}
      </div>
    </div>
  );
}
