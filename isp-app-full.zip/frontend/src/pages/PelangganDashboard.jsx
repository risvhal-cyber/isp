import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { StatusBadge } from "../components/StatusBadge";
import { RedamanGauge } from "../components/RedamanGauge";
import { api, auth } from "../lib/api";

export default function PelangganDashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [memproses, setMemproses] = useState(null);
  const navigate = useNavigate();
  const user = auth.ambilUser();

  useEffect(() => {
    api
      .dashboardPelanggan()
      .then(setData)
      .catch((err) => setError(err.message));
  }, []);

  async function bayarSekarang(tagihanId) {
    setMemproses(tagihanId);
    try {
      const link = await api.buatLinkPembayaran(tagihanId);
      window.open(link.redirectUrl, "_blank");
    } catch (err) {
      alert(err.message);
    } finally {
      setMemproses(null);
    }
  }

  function logout() {
    auth.hapusToken();
    navigate("/login");
  }

  return (
    <div style={{ maxWidth: 480, margin: "0 auto", padding: "24px 18px 60px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <div className="mono" style={{ color: "var(--accent)", fontSize: 12, letterSpacing: "0.05em" }}>
            HALO
          </div>
          <h1 style={{ fontSize: 22, marginTop: 2 }}>{user?.nama}</h1>
        </div>
        <button className="btn btn-ghost" onClick={logout} style={{ fontSize: 13, padding: "8px 14px" }}>
          Keluar
        </button>
      </div>

      {error && (
        <div className="card" style={{ borderColor: "var(--critical)" }}>
          Gagal memuat data: {error}
        </div>
      )}

      {data && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {/* Status koneksi */}
          <div className="card">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 6 }}>Status koneksi</div>
                <div style={{ fontWeight: 600, fontSize: 16 }}>{data.paketLangganan || "Paket belum diatur"}</div>
              </div>
              <StatusBadge status={data.statusKoneksi?.status} />
            </div>
          </div>

          {/* Redaman */}
          <div className="card">
            <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 14 }}>
              Kekuatan sinyal (redaman)
            </div>
            <RedamanGauge dbm={data.redamanTerakhir?.rxPower ?? null} />
          </div>

          {/* Tagihan */}
          <div>
            <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 10, marginTop: 6 }}>
              Tagihan terakhir
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {data.tagihanTerakhir?.length === 0 && (
                <div className="card" style={{ color: "var(--text-muted)", fontSize: 14 }}>
                  Belum ada tagihan.
                </div>
              )}
              {data.tagihanTerakhir?.map((t) => (
                <div key={t.id} className="card">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontWeight: 600 }}>{t.periode}</div>
                      <div className="mono" style={{ fontSize: 15, marginTop: 4 }}>
                        Rp{t.jumlah.toLocaleString("id-ID")}
                      </div>
                    </div>
                    <StatusBadge status={t.status} />
                  </div>
                  {t.status !== "LUNAS" && (
                    <button
                      className="btn btn-primary"
                      style={{ width: "100%", marginTop: 14 }}
                      onClick={() => bayarSekarang(t.id)}
                      disabled={memproses === t.id}
                    >
                      {memproses === t.id ? "Membuka..." : "Bayar sekarang"}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
