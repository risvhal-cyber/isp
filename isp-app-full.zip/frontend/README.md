# Frontend — Dashboard ISP App

React + Vite. Terhubung ke backend yang sudah dibuat sebelumnya (auth, mikrotik, WA, payment).

## Cara menjalankan

1. Pastikan backend sudah jalan (lihat README di folder `backend/`).
2. Install dependency:
   ```
   npm install
   ```
3. Copy env:
   ```
   cp .env.example .env
   ```
   Sesuaikan `VITE_API_URL` kalau backend tidak di `localhost:3000`.
4. Jalankan:
   ```
   npm run dev
   ```
   Buka `http://localhost:5173`

## Yang sudah ada

- **Login** — satu form untuk semua role (admin, penagih, pelanggan), otomatis diarahkan ke dashboard sesuai role
- **Dashboard Admin** — ringkasan sistem (jumlah pelanggan, router, OLT, tagihan belum lunas) + status live tiap router Mikrotik (CPU, uptime, online/offline)
- **Dashboard Pelanggan** — mobile-first (karena ini nanti dibungkus jadi APK): status koneksi real-time, gauge redaman dengan kode warna, daftar tagihan + tombol bayar langsung ke Midtrans

## Belum ada (menyusul)
- Halaman detail Mikrotik (tambah/hapus router dari UI — endpoint API-nya sudah ada)
- Halaman OLT (nunggu integrasi backend selesai)
- Halaman kelola pelanggan & tagihan untuk admin/penagih
- Halaman WA Gateway (scan QR dari UI)

## Konversi ke APK Android

Setelah dashboard ini stabil dan sudah dites, langkah convert ke APK:
```
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init
npm run build
npx cap add android
npx cap sync
npx cap open android
```
Lalu build APK dari Android Studio yang terbuka otomatis.
