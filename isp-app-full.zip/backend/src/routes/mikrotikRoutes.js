const express = require("express");
const router = express.Router();
const {
  tambahMikrotik,
  hapusMikrotik,
  listMikrotik,
  statusMikrotik,
  statusSemuaMikrotik,
} = require("../controllers/mikrotikController");
const { verifyToken, allowRoles } = require("../middleware/auth");

// Semua endpoint Mikrotik hanya untuk ADMIN (kelola infrastruktur jaringan)
router.use(verifyToken, allowRoles("ADMIN"));

router.get("/", listMikrotik);
router.post("/", tambahMikrotik);
router.delete("/:id", hapusMikrotik);
router.get("/status-semua", statusSemuaMikrotik);
router.get("/:id/status", statusMikrotik);

module.exports = router;
