const express = require("express");
const router = express.Router();
const { register, login } = require("../controllers/authController");
const { verifyToken, allowRoles } = require("../middleware/auth");

// Hanya admin yang boleh membuat akun baru (admin/penagih/pelanggan)
router.post("/register", verifyToken, allowRoles("ADMIN"), register);

router.post("/login", login);

module.exports = router;
