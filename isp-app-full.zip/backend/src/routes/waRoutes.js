const express = require("express");
const router = express.Router();
const {
  ambilQr,
  statusWa,
  kirimTest,
  notifGangguan,
  notifJatuhTempoManual,
  logWa,
} = require("../controllers/waController");
const { verifyToken, allowRoles } = require("../middleware/auth");

// Semua endpoint WA hanya untuk ADMIN
router.use(verifyToken, allowRoles("ADMIN"));

router.get("/qr", ambilQr);
router.get("/status", statusWa);
router.post("/kirim-test", kirimTest);
router.post("/notifikasi/gangguan", notifGangguan);
router.post("/notifikasi/jatuh-tempo", notifJatuhTempoManual);
router.get("/log", logWa);

module.exports = router;
