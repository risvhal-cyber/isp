const express = require("express");
const router = express.Router();
const prisma = require("../config/prisma");
const { verifyToken, allowRoles } = require("../middleware/auth");
const mikrotikService = require("../services/mikrotikService");

// Dashboard admin: ringkasan jumlah pelanggan, mikrotik, olt, tagihan belum lunas,
// plus status live tiap router Mikrotik (CPU, RAM, interface)
router.get("/admin", verifyToken, allowRoles("ADMIN"), async (req, res) => {
  const [jumlahPelanggan, daftarMikrotik, jumlahOlt, tagihanBelumLunas] = await Promise.all([
    prisma.pelanggan.count(),
    prisma.mikrotik.findMany({ where: { aktif: true } }),
    prisma.olt.count(),
    prisma.tagihan.count({ where: { status: "BELUM_BAYAR" } }),
  ]);

  const statusMikrotik = await Promise.all(
    daftarMikrotik.map(async (m) => ({
      id: m.id,
      nama: m.nama,
      ...(await mikrotikService.ambilStatusRouter(m)),
    }))
  );

  res.json({
    jumlahPelanggan,
    jumlahMikrotik: daftarMikrotik.length,
    jumlahOlt,
    tagihanBelumLunas,
    statusMikrotik,
    // status OLT & redaman akan ditambahkan di modul OLT
  });
});

// Dashboard pelanggan: status koneksi & redaman miliknya sendiri
router.get("/pelanggan", verifyToken, allowRoles("PELANGGAN"), async (req, res) => {
  const pelanggan = await prisma.pelanggan.findUnique({
    where: { userId: req.user.id },
    include: {
      redaman: { orderBy: { createdAt: "desc" }, take: 1 },
      tagihan: { orderBy: { createdAt: "desc" }, take: 3 },
    },
  });

  if (!pelanggan) {
    return res.status(404).json({ error: "Data pelanggan tidak ditemukan" });
  }

  // Cek status koneksi real-time (online/offline) lewat PPPoE di Mikrotik,
  // hanya kalau pelanggan ini sudah dikaitkan dengan sebuah secret name
  let statusKoneksi = { status: "TIDAK_DIKETAHUI" };
  if (pelanggan.mikrotikSecretName) {
    const mikrotikAktif = await prisma.mikrotik.findFirst({ where: { aktif: true } });
    if (mikrotikAktif) {
      try {
        statusKoneksi = await mikrotikService.cekStatusPelanggan(mikrotikAktif, pelanggan.mikrotikSecretName);
      } catch (err) {
        statusKoneksi = { status: "TIDAK_DIKETAHUI", error: err.message };
      }
    }
  }

  res.json({
    statusLangganan: pelanggan.statusLangganan,
    paketLangganan: pelanggan.paketLangganan,
    statusKoneksi,
    redamanTerakhir: pelanggan.redaman[0] || null,
    tagihanTerakhir: pelanggan.tagihan,
  });
});

module.exports = router;
