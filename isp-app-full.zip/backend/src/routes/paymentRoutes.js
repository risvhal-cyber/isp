const express = require("express");
const router = express.Router();
const { buatLinkPembayaran, webhookMidtrans, catatPembayaranManual } = require("../controllers/paymentController");
const { verifyToken, allowRoles } = require("../middleware/auth");

// Webhook Midtrans — HARUS publik, jangan pakai verifyToken.
// Keamanannya dijamin lewat verifikasi signature di dalam controller.
router.post("/webhook", webhookMidtrans);

// Buat link pembayaran — admin/penagih bisa generate untuk pelanggan manapun,
// pelanggan hanya bisa untuk tagihannya sendiri (dicek di controller)
router.post(
  "/tagihan/:tagihanId/bayar",
  verifyToken,
  allowRoles("ADMIN", "PENAGIH", "PELANGGAN"),
  buatLinkPembayaran
);

// Penagih catat pembayaran manual (tunai/transfer langsung di lapangan)
router.post(
  "/tagihan/:tagihanId/bayar-manual",
  verifyToken,
  allowRoles("ADMIN", "PENAGIH"),
  catatPembayaranManual
);

module.exports = router;
