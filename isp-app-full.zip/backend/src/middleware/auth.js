const jwt = require("jsonwebtoken");

// Memastikan request punya token JWT yang valid
function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Token tidak ditemukan" });
  }

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // { id, role, email }
    next();
  } catch (err) {
    return res.status(401).json({ error: "Token tidak valid atau kedaluwarsa" });
  }
}

// Membatasi endpoint hanya untuk role tertentu.
// Contoh pemakaian: allowRoles("ADMIN", "PENAGIH")
function allowRoles(...rolesYangDiizinkan) {
  return (req, res, next) => {
    if (!req.user || !rolesYangDiizinkan.includes(req.user.role)) {
      return res.status(403).json({ error: "Akses ditolak untuk role ini" });
    }
    next();
  };
}

module.exports = { verifyToken, allowRoles };
