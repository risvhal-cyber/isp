const cron = require("node-cron");
const notifikasiService = require("../services/notifikasiService");

// Jalan tiap hari jam 9 pagi — cek tagihan yang akan jatuh tempo dalam 3 hari
function jadwalkanPengingatHarian() {
  cron.schedule("0 9 * * *", async () => {
    console.log("Menjalankan pengingat jatuh tempo harian...");
    try {
      await notifikasiService.jalankanPengingatHarian();
    } catch (err) {
      console.error("Gagal menjalankan pengingat harian:", err.message);
    }
  });
  console.log("Cron pengingat jatuh tempo terjadwal: setiap hari jam 09:00");
}

module.exports = { jadwalkanPengingatHarian };
