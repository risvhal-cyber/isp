require("dotenv").config();
const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/authRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");
const mikrotikRoutes = require("./routes/mikrotikRoutes");
const waRoutes = require("./routes/waRoutes");
const paymentRoutes = require("./routes/paymentRoutes");
const waService = require("./services/waService");
const { jadwalkanPengingatHarian } = require("./cron/jadwal");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ status: "ok", message: "ISP App Backend berjalan" });
});

app.use("/api/auth", authRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/mikrotik", mikrotikRoutes);
app.use("/api/wa", waRoutes);
app.use("/api/payment", paymentRoutes);

// Modul berikutnya akan ditambahkan di sini:
// app.use("/api/olt", oltRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);

  // Mulai koneksi WA gateway — pertama kali jalan, buka /api/wa/qr untuk scan
  try {
    await waService.mulaiKoneksiWa();
  } catch (err) {
    console.error("Gagal memulai WA gateway:", err.message);
  }

  jadwalkanPengingatHarian();
});
