const waService = require("../services/waService");
const notifikasiService = require("../services/notifikasiService");
const prisma = require("../config/prisma");

// Admin scan QR ini sekali di awal untuk login WA (nomor WA khusus bisnis, bukan pribadi)
async function ambilQr(req, res) {
  const status = waService.ambilStatusWa();
  if (status.status === "TERHUBUNG") {
    return res.json({ status: "TERHUBUNG", pesan: "WA sudah terhubung, tidak perlu scan lagi" });
  }

  const qrDataUrl = await waService.ambilQrDataUrl();
  if (!qrDataUrl) {
    return res.status(202).json({ status: "MENUNGGU", pesan: "QR belum siap, coba lagi beberapa detik" });
  }

  res.json({ status: "MENUNGGU_SCAN", qrDataUrl });
}

function statusWa(req, res) {
  res.json(waService.ambilStatusWa());
}

// Kirim pesan manual/test ke satu nomor
async function kirimTest(req, res) {
  try {
    const { nomor, pesan } = req.body;
    if (!nomor || !pesan) return res.status(400).json({ error: "nomor dan pesan wajib diisi" });

    await waService.kirimPesan(nomor, pesan);
    res.json({ message: "Pesan terkirim" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// Trigger manual notifikasi gangguan ke satu atau banyak pelanggan
async function notifGangguan(req, res) {
  try {
    const { pelangganIds, keterangan } = req.body;
    if (!Array.isArray(pelangganIds) || !keterangan) {
      return res.status(400).json({ error: "pelangganIds (array) dan keterangan wajib diisi" });
    }

    const hasil = [];
    for (const id of pelangganIds) {
      hasil.push({ pelangganId: id, ...(await notifikasiService.kirimNotifGangguan(id, keterangan)) });
    }
    res.json({ hasil });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// Trigger manual pengingat jatuh tempo (biasanya jalan otomatis via cron, ini buat testing)
async function notifJatuhTempoManual(req, res) {
  try {
    await notifikasiService.jalankanPengingatHarian();
    res.json({ message: "Pengingat jatuh tempo diproses, cek log WA untuk detail" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// Lihat riwayat notifikasi yang sudah dikirim
async function logWa(req, res) {
  const logs = await prisma.logWa.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { pelanggan: { include: { user: { select: { nama: true } } } } },
  });
  res.json(logs);
}

module.exports = { ambilQr, statusWa, kirimTest, notifGangguan, notifJatuhTempoManual, logWa };
