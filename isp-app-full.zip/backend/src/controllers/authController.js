const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const prisma = require("../config/prisma");

// Dipakai admin untuk membuat akun baru (admin/penagih/pelanggan)
async function register(req, res) {
  try {
    const { nama, email, password, role, telepon, alamat, paketLangganan, biayaBulanan, tanggalJatuhTempo } = req.body;

    if (!nama || !email || !password || !role) {
      return res.status(400).json({ error: "nama, email, password, dan role wajib diisi" });
    }
    if (!["ADMIN", "PENAGIH", "PELANGGAN"].includes(role)) {
      return res.status(400).json({ error: "role tidak valid" });
    }

    const sudahAda = await prisma.user.findUnique({ where: { email } });
    if (sudahAda) {
      return res.status(409).json({ error: "Email sudah terdaftar" });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: {
        nama,
        email,
        passwordHash,
        role,
        telepon,
        // Jika role PELANGGAN, langsung buat data pelanggan terkait
        pelanggan:
          role === "PELANGGAN"
            ? {
                create: {
                  alamat,
                  paketLangganan,
                  biayaBulanan: biayaBulanan || 0,
                  tanggalJatuhTempo: tanggalJatuhTempo || 1,
                },
              }
            : undefined,
      },
    });

    res.status(201).json({ id: user.id, nama: user.nama, email: user.email, role: user.role });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal mendaftarkan user" });
  }
}

async function login(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "email dan password wajib diisi" });
    }

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      return res.status(401).json({ error: "Email atau password salah" });
    }

    const cocok = await bcrypt.compare(password, user.passwordHash);
    if (!cocok) {
      return res.status(401).json({ error: "Email atau password salah" });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, email: user.email, nama: user.nama },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({ token, user: { id: user.id, nama: user.nama, email: user.email, role: user.role } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal login" });
  }
}

module.exports = { register, login };
