const prisma = require("../config/prisma");
const paymentService = require("../services/paymentService");
const notifikasiService = require("../services/notifikasiService");

// Admin/penagih generate link pembayaran untuk satu tagihan
// (atau bisa juga dipanggil dari dashboard pelanggan supaya pelanggan bayar sendiri)
async function buatLinkPembayaran(req, res) {
  try {
    const { tagihanId } = req.params;
    const tagihan = await prisma.tagihan.findUnique({
      where: { id: tagihanId },
      include: { pelanggan: { include: { user: true } } },
    });

    if (!tagihan) return res.status(404).json({ error: "Tagihan tidak ditemukan" });
    if (tagihan.status === "LUNAS") return res.status(400).json({ error: "Tagihan sudah lunas" });

    // Kalau yang minta adalah pelanggan, pastikan tagihan ini memang miliknya sendiri
    if (req.user.role === "PELANGGAN" && tagihan.pelanggan.userId !== req.user.id) {
      return res.status(403).json({ error: "Tidak bisa mengakses tagihan milik pelanggan lain" });
    }

    const link = await paymentService.buatLinkPembayaran(tagihan, tagihan.pelanggan);

    // simpan order_id sementara supaya bisa dicocokkan saat webhook masuk
    await prisma.tagihan.update({
      where: { id: tagihanId },
      data: { referensiPembayaran: link.orderId },
    });

    res.json(link);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal membuat link pembayaran: " + err.message });
  }
}

// Webhook dari Midtrans — dipanggil otomatis oleh Midtrans, BUKAN oleh user.
// Endpoint ini publik (tidak pakai verifyToken), makanya wajib verifikasi signature.
async function webhookMidtrans(req, res) {
  try {
    const body = req.body;

    if (!paymentService.verifikasiSignature(body)) {
      return res.status(403).json({ error: "Signature tidak valid" });
    }

    const { order_id, transaction_status, payment_type } = body;

    const tagihan = await prisma.tagihan.findFirst({
      where: { referensiPembayaran: order_id },
    });
    if (!tagihan) {
      // Bukan error fatal — Midtrans tetap perlu respons 200 supaya tidak retry terus
      return res.status(200).json({ message: "Tagihan tidak ditemukan, diabaikan" });
    }

    if (["settlement", "capture"].includes(transaction_status)) {
      await prisma.tagihan.update({
        where: { id: tagihan.id },
        data: {
          status: "LUNAS",
          tanggalBayar: new Date(),
          metodePembayaran: payment_type,
        },
      });

      // otomatis kirim struk WA setelah pembayaran sukses
      await notifikasiService.kirimStrukPembayaran(tagihan.id);
    } else if (["deny", "cancel", "expire"].includes(transaction_status)) {
      await prisma.tagihan.update({
        where: { id: tagihan.id },
        data: { status: "BELUM_BAYAR" },
      });
    }

    res.status(200).json({ message: "Webhook diproses" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal memproses webhook" });
  }
}

// Penagih mencatat pembayaran manual (tunai/transfer langsung, bukan lewat Midtrans)
async function catatPembayaranManual(req, res) {
  try {
    const { tagihanId } = req.params;
    const tagihan = await prisma.tagihan.findUnique({ where: { id: tagihanId } });
    if (!tagihan) return res.status(404).json({ error: "Tagihan tidak ditemukan" });
    if (tagihan.status === "LUNAS") return res.status(400).json({ error: "Tagihan sudah lunas" });

    await prisma.tagihan.update({
      where: { id: tagihanId },
      data: {
        status: "LUNAS",
        tanggalBayar: new Date(),
        metodePembayaran: "TUNAI",
      },
    });

    await notifikasiService.kirimStrukPembayaran(tagihanId);
    res.json({ message: "Pembayaran dicatat, struk terkirim" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal mencatat pembayaran" });
  }
}

module.exports = { buatLinkPembayaran, webhookMidtrans, catatPembayaranManual };
