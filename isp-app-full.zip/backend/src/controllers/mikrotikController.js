const prisma = require("../config/prisma");
const mikrotikService = require("../services/mikrotikService");

// Tambah router Mikrotik baru
async function tambahMikrotik(req, res) {
  try {
    const { nama, ipAddress, port, username, password } = req.body;
    if (!nama || !ipAddress || !username || !password) {
      return res.status(400).json({ error: "nama, ipAddress, username, dan password wajib diisi" });
    }

    const mikrotik = await prisma.mikrotik.create({
      data: { nama, ipAddress, port: port || 8728, username, password },
    });

    // langsung cek apakah bisa konek, biar admin tahu kalau ada yang salah input
    const tesKoneksi = await mikrotikService.ambilStatusRouter(mikrotik);

    res.status(201).json({ mikrotik: { ...mikrotik, password: undefined }, tesKoneksi });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal menambahkan router Mikrotik" });
  }
}

// Hapus router Mikrotik
async function hapusMikrotik(req, res) {
  try {
    const { id } = req.params;
    await prisma.mikrotik.delete({ where: { id } });
    res.json({ message: "Router berhasil dihapus" });
  } catch (err) {
    res.status(404).json({ error: "Router tidak ditemukan" });
  }
}

// List semua router yang terdaftar (tanpa password)
async function listMikrotik(req, res) {
  const daftar = await prisma.mikrotik.findMany({
    select: { id: true, nama: true, ipAddress: true, port: true, aktif: true, createdAt: true },
  });
  res.json(daftar);
}

// Ambil status live satu router (CPU, RAM, interface, traffic)
async function statusMikrotik(req, res) {
  try {
    const { id } = req.params;
    const mikrotik = await prisma.mikrotik.findUnique({ where: { id } });
    if (!mikrotik) return res.status(404).json({ error: "Router tidak ditemukan" });

    const status = await mikrotikService.ambilStatusRouter(mikrotik);
    res.json(status);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Gagal mengambil status router" });
  }
}

// Dashboard ringkas: status semua router sekaligus (dipakai di dashboard admin)
async function statusSemuaMikrotik(req, res) {
  const daftar = await prisma.mikrotik.findMany({ where: { aktif: true } });
  const hasil = await Promise.all(
    daftar.map(async (mikrotik) => ({
      id: mikrotik.id,
      nama: mikrotik.nama,
      ipAddress: mikrotik.ipAddress,
      ...(await mikrotikService.ambilStatusRouter(mikrotik)),
    }))
  );
  res.json(hasil);
}

module.exports = { tambahMikrotik, hapusMikrotik, listMikrotik, statusMikrotik, statusSemuaMikrotik };
