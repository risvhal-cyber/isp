const midtransClient = require("midtrans-client");
const crypto = require("crypto");

const snap = new midtransClient.Snap({
  isProduction: process.env.MIDTRANS_IS_PRODUCTION === "true",
  serverKey: process.env.MIDTRANS_SERVER_KEY,
  clientKey: process.env.MIDTRANS_CLIENT_KEY,
});

// Buat link pembayaran (Snap) untuk satu tagihan.
// Snap otomatis kasih pilihan VA, QRIS, e-wallet, dll ke pelanggan.
async function buatLinkPembayaran(tagihan, pelanggan) {
  const parameter = {
    transaction_details: {
      order_id: `TAGIHAN-${tagihan.id}-${Date.now()}`, // unik tiap percobaan bayar
      gross_amount: tagihan.jumlah,
    },
    customer_details: {
      first_name: pelanggan.user.nama,
      phone: pelanggan.user.telepon || undefined,
    },
    item_details: [
      {
        id: tagihan.id,
        price: tagihan.jumlah,
        quantity: 1,
        name: `Tagihan Internet ${tagihan.periode}`,
      },
    ],
  };

  const transaksi = await snap.createTransaction(parameter);
  return {
    orderId: parameter.transaction_details.order_id,
    redirectUrl: transaksi.redirect_url,
    token: transaksi.token,
  };
}

// Verifikasi signature dari webhook Midtrans supaya tidak bisa dipalsukan orang lain.
// Formula resmi Midtrans: SHA512(order_id + status_code + gross_amount + ServerKey)
function verifikasiSignature(body) {
  const { order_id, status_code, gross_amount, signature_key } = body;
  const rawString = order_id + status_code + gross_amount + process.env.MIDTRANS_SERVER_KEY;
  const hash = crypto.createHash("sha512").update(rawString).digest("hex");
  return hash === signature_key;
}

module.exports = { buatLinkPembayaran, verifikasiSignature };
