const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const QRCode = require("qrcode");
const path = require("path");

// State koneksi disimpan di memori proses ini.
// qrTerakhir: dipakai supaya admin bisa scan lewat endpoint /api/wa/qr
// status: "MENUNGGU_SCAN" | "TERHUBUNG" | "TERPUTUS"
let sock = null;
let qrTerakhir = null;
let statusKoneksi = "TERPUTUS";

const FOLDER_AUTH = path.join(__dirname, "../../wa-auth"); // simpan sesi login, jangan di-commit ke git

async function mulaiKoneksiWa() {
  const { state, saveCreds } = await useMultiFileAuthState(FOLDER_AUTH);

  sock = makeWASocket({
    auth: state,
    logger: pino({ level: "silent" }), // matikan log verbose Baileys
    printQRInTerminal: false,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      qrTerakhir = qr;
      statusKoneksi = "MENUNGGU_SCAN";
    }

    if (connection === "open") {
      statusKoneksi = "TERHUBUNG";
      qrTerakhir = null;
      console.log("WA Gateway: berhasil terhubung");
    }

    if (connection === "close") {
      statusKoneksi = "TERPUTUS";
      const alasan = lastDisconnect?.error?.output?.statusCode;
      const perluLoginUlang = alasan === DisconnectReason.loggedOut;
      console.log("WA Gateway: koneksi terputus. Login ulang?", perluLoginUlang);
      if (!perluLoginUlang) {
        // reconnect otomatis kalau bukan karena logout manual
        mulaiKoneksiWa();
      }
    }
  });

  return sock;
}

// Ambil QR code terakhir dalam bentuk data URL (buat ditampilkan di halaman admin)
async function ambilQrDataUrl() {
  if (!qrTerakhir) return null;
  return QRCode.toDataURL(qrTerakhir);
}

function ambilStatusWa() {
  return { status: statusKoneksi };
}

// Kirim pesan teks ke satu nomor.
// nomor format bebas (misal "08123456789" atau "628123456789"), otomatis dirapikan.
async function kirimPesan(nomor, pesan) {
  if (statusKoneksi !== "TERHUBUNG") {
    throw new Error("WA belum terhubung, scan QR dulu di /api/wa/qr");
  }

  let nomorRapi = nomor.replace(/\D/g, ""); // buang karakter selain angka
  if (nomorRapi.startsWith("0")) {
    nomorRapi = "62" + nomorRapi.slice(1);
  }
  const jid = `${nomorRapi}@s.whatsapp.net`;

  await sock.sendMessage(jid, { text: pesan });
  return true;
}

module.exports = { mulaiKoneksiWa, ambilQrDataUrl, ambilStatusWa, kirimPesan };
