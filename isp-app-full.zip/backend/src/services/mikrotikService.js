const { RouterOSAPI } = require("node-routeros");

// Membuka koneksi baru ke satu router Mikrotik.
// Dipanggil per-request (bukan disimpan permanen) supaya aman kalau
// ada banyak router terdaftar dan sebagian sedang mati/tidak bisa diakses.
function bukaKoneksi(mikrotik) {
  return new RouterOSAPI({
    host: mikrotik.ipAddress,
    port: mikrotik.port,
    user: mikrotik.username,
    password: mikrotik.password,
    timeout: 8, // detik — jangan terlalu lama nunggu kalau router mati
  });
}

// Ambil status umum: identity, uptime, resource (CPU/RAM), dan daftar interface.
async function ambilStatusRouter(mikrotik) {
  const conn = bukaKoneksi(mikrotik);
  try {
    await conn.connect();

    const [identity] = await conn.write("/system/identity/print");
    const [resource] = await conn.write("/system/resource/print");
    const interfaces = await conn.write("/interface/print");

    return {
      online: true,
      identity: identity?.name,
      cpuLoad: resource?.["cpu-load"],
      freeMemory: resource?.["free-memory"],
      totalMemory: resource?.["total-memory"],
      uptime: resource?.uptime,
      versi: resource?.version,
      interfaces: interfaces.map((i) => ({
        nama: i.name,
        tipe: i.type,
        aktif: i.running === "true",
        disabled: i.disabled === "true",
        rxByte: i["rx-byte"],
        txByte: i["tx-byte"],
      })),
    };
  } catch (err) {
    return { online: false, error: err.message };
  } finally {
    conn.close();
  }
}

// Ambil daftar koneksi PPPoE aktif — dipakai untuk cek status koneksi
// pelanggan tertentu (dicocokkan lewat mikrotikSecretName di data Pelanggan).
async function ambilPppoeAktif(mikrotik) {
  const conn = bukaKoneksi(mikrotik);
  try {
    await conn.connect();
    const aktif = await conn.write("/ppp/active/print");
    return aktif.map((a) => ({
      nama: a.name,
      alamatIp: a.address,
      uptime: a.uptime,
      callerId: a["caller-id"],
    }));
  } finally {
    conn.close();
  }
}

// Cek status koneksi satu pelanggan spesifik berdasarkan nama secret PPPoE-nya
async function cekStatusPelanggan(mikrotik, mikrotikSecretName) {
  const daftarAktif = await ambilPppoeAktif(mikrotik);
  const ditemukan = daftarAktif.find((a) => a.nama === mikrotikSecretName);
  return ditemukan ? { status: "ONLINE", ...ditemukan } : { status: "OFFLINE" };
}

module.exports = { ambilStatusRouter, ambilPppoeAktif, cekStatusPelanggan };
