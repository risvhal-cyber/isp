const prisma = require("../config/prisma");
const waService = require("./waService");

// Fungsi pembantu: kirim pesan lalu catat hasilnya ke tabel LogWa
async function kirimDanCatat(pelanggan, jenis, pesan) {
  if (!pelanggan.user?.telepon) {
    await prisma.logWa.create({
      data: { pelangganId: pelanggan.id, jenis, pesan, status: "GAGAL" },
    });
    return { berhasil: false, alasan: "Pelanggan tidak punya nomor telepon" };
  }

  try {
    await waService.kirimPesan(pelanggan.user.telepon, pesan);
    await prisma.logWa.create({
      data: { pelangganId: pelanggan.id, jenis, pesan, status: "TERKIRIM" },
    });
    return { berhasil: true };
  } catch (err) {
    await prisma.logWa.create({
      data: { pelangganId: pelanggan.id, jenis, pesan, status: "GAGAL" },
    });
    return { berhasil: false, alasan: err.message };
  }
}

// 1. Notifikasi gangguan jaringan
async function kirimNotifGangguan(pelangganId, keteranganGangguan) {
  const pelanggan = await prisma.pelanggan.findUnique({
    where: { id: pelangganId },
    include: { user: true },
  });
  if (!pelanggan) throw new Error("Pelanggan tidak ditemukan");

  const pesan =
    `Halo ${pelanggan.user.nama}, kami informasikan sedang terjadi gangguan jaringan:\n` +
    `${keteranganGangguan}\n\n` +
    `Tim teknisi kami sedang menangani. Mohon maaf atas ketidaknyamanannya.`;

  return kirimDanCatat(pelanggan, "GANGGUAN", pesan);
}

// 2. Notifikasi mendekati jatuh tempo (dipanggil oleh cron harian)
async function kirimNotifJatuhTempo(pelangganId, tagihan) {
  const pelanggan = await prisma.pelanggan.findUnique({
    where: { id: pelangganId },
    include: { user: true },
  });
  if (!pelanggan) throw new Error("Pelanggan tidak ditemukan");

  const tanggal = new Date(tagihan.tanggalJatuhTempo).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const pesan =
    `Halo ${pelanggan.user.nama}, ini pengingat tagihan internet periode ${tagihan.periode}\n` +
    `Jumlah: Rp${tagihan.jumlah.toLocaleString("id-ID")}\n` +
    `Jatuh tempo: ${tanggal}\n\n` +
    `Mohon lakukan pembayaran sebelum tanggal tersebut untuk menghindari isolir. Terima kasih.`;

  return kirimDanCatat(pelanggan, "JATUH_TEMPO", pesan);
}

// 3. Struk pembayaran (dipanggil setelah webhook payment gateway sukses)
async function kirimStrukPembayaran(tagihanId) {
  const tagihan = await prisma.tagihan.findUnique({
    where: { id: tagihanId },
    include: { pelanggan: { include: { user: true } } },
  });
  if (!tagihan) throw new Error("Tagihan tidak ditemukan");

  const pelanggan = tagihan.pelanggan;
  const tanggalBayar = (tagihan.tanggalBayar || new Date()).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const pesan =
    `Terima kasih ${pelanggan.user.nama}, pembayaran kamu sudah kami terima.\n\n` +
    `--- BUKTI PEMBAYARAN ---\n` +
    `Periode: ${tagihan.periode}\n` +
    `Jumlah: Rp${tagihan.jumlah.toLocaleString("id-ID")}\n` +
    `Metode: ${tagihan.metodePembayaran || "-"}\n` +
    `Tanggal: ${tanggalBayar}\n` +
    `Ref: ${tagihan.referensiPembayaran || "-"}\n` +
    `------------------------\n` +
    `Simpan pesan ini sebagai bukti pembayaran resmi.`;

  return kirimDanCatat(pelanggan, "STRUK_PEMBAYARAN", pesan);
}

// Dipanggil cron harian: cari semua tagihan yang jatuh tempo dalam 3 hari
// dan belum lunas, lalu kirim pengingat satu-satu.
async function jalankanPengingatHarian() {
  const sekarang = new Date();
  const batasAtas = new Date();
  batasAtas.setDate(sekarang.getDate() + 3);

  const tagihanAkanJatuhTempo = await prisma.tagihan.findMany({
    where: {
      status: "BELUM_BAYAR",
      tanggalJatuhTempo: { gte: sekarang, lte: batasAtas },
    },
  });

  console.log(`Pengingat harian: ${tagihanAkanJatuhTempo.length} tagihan akan jatuh tempo`);

  for (const tagihan of tagihanAkanJatuhTempo) {
    await kirimNotifJatuhTempo(tagihan.pelangganId, tagihan);
  }
}

module.exports = {
  kirimNotifGangguan,
  kirimNotifJatuhTempo,
  kirimStrukPembayaran,
  jalankanPengingatHarian,
};
