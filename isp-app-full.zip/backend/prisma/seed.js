// Jalankan sekali di awal: node prisma/seed.js
// Membuat akun admin pertama, karena endpoint /register butuh login admin duluan.
const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const prisma = new PrismaClient();

async function main() {
  const email = process.env.SEED_ADMIN_EMAIL || "admin@isp.local";
  const password = process.env.SEED_ADMIN_PASSWORD || "ubah-password-ini";

  const sudahAda = await prisma.user.findUnique({ where: { email } });
  if (sudahAda) {
    console.log("Admin sudah ada:", email);
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const admin = await prisma.user.create({
    data: {
      nama: "Admin",
      email,
      passwordHash,
      role: "ADMIN",
    },
  });

  console.log("Admin berhasil dibuat:");
  console.log("  email:", admin.email);
  console.log("  password:", password, "(SEGERA GANTI setelah login pertama)");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
