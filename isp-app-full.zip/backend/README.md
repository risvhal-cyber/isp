# Backend Aplikasi Manajemen Pelanggan ISP

## Cara menjalankan (di komputer/VPS yang ada internet)

1. Install dependency:
   ```
   npm install
   ```

2. Copy `.env.example` jadi `.env`, lalu sesuaikan isinya:
   ```
   cp .env.example .env
   ```

3. Generate Prisma client & buat database (SQLite untuk dev):
   ```
   npx prisma generate
   npx prisma migrate dev --name init
   ```

4. Buat akun admin pertama:
   ```
   node prisma/seed.js
   ```
   Ini akan mencetak email & password admin (default: admin@isp.local — SEGERA login dan ganti password).

5. Jalankan server (mode development, auto-reload):
   ```
   npm run dev
   ```
   Server jalan di `http://localhost:3000`

## Struktur yang sudah ada

- **Auth**: register (khusus admin membuat akun baru), login (semua role) — JWT
- **3 Role**: ADMIN, PENAGIH, PELANGGAN — dibatasi lewat middleware `allowRoles`
- **Dashboard**: endpoint dasar untuk admin (ringkasan sistem) dan pelanggan (status koneksi & redaman miliknya)
- **Skema database**: sudah mencakup Pelanggan, Tagihan, Mikrotik, OLT, LogRedaman, LogWa — siap diisi logic modul berikutnya

## Test cepat pakai curl

```bash
# Login sebagai admin
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@isp.local","password":"ganti-password-ini"}'

# Pakai token dari response di atas untuk buat user baru
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer TOKEN_ADMIN_DISINI" \
  -d '{"nama":"Budi","email":"budi@example.com","password":"rahasia123","role":"PELANGGAN","telepon":"08123456789","alamat":"Jl. Contoh No.1","paketLangganan":"20 Mbps","biayaBulanan":150000,"tanggalJatuhTempo":5}'
```

## Modul Mikrotik (sudah jadi)

Pastikan RouterOS API service aktif di Mikrotik kamu: `IP > Services > api` (default port 8728).

- `POST /api/mikrotik` — tambah router baru (admin). Body: `{ "nama": "Router Pusat", "ipAddress": "192.168.1.1", "port": 8728, "username": "admin", "password": "xxx" }`. Otomatis tes koneksi setelah disimpan.
- `DELETE /api/mikrotik/:id` — hapus router
- `GET /api/mikrotik` — list semua router terdaftar
- `GET /api/mikrotik/:id/status` — status live satu router (CPU, RAM, uptime, daftar interface + traffic)
- `GET /api/mikrotik/status-semua` — status live semua router sekaligus

Dashboard admin (`GET /api/dashboard/admin`) otomatis menampilkan status semua router Mikrotik yang aktif.

Untuk cek status koneksi pelanggan tertentu (online/offline via PPPoE), isi field `mikrotikSecretName` pada data Pelanggan (samakan dengan nama secret PPPoE di Mikrotik) — nanti otomatis muncul di dashboard pelanggan.

## Modul WA Gateway (sudah jadi — pakai Baileys, gratis & self-hosted)

**PENTING**: gunakan nomor WA khusus bisnis (bukan nomor pribadi utama), karena Baileys adalah API tidak resmi — ada risiko kena banned kalau kirim pesan terlalu banyak/cepat.

1. Jalankan server (`npm run dev`), lalu buka:
   ```
   GET /api/wa/qr
   ```
   (pakai token admin). Responnya berisi `qrDataUrl` (base64 image) — buka di browser atau tempel ke `<img src="...">` untuk di-scan pakai WhatsApp di HP (Perangkat Tertaut).

2. Setelah discan, cek status:
   ```
   GET /api/wa/status
   ```
   Harus jadi `{ "status": "TERHUBUNG" }`. Sesi login tersimpan di folder `wa-auth/` — server tidak perlu scan ulang tiap restart, kecuali logout manual dari HP.

3. Test kirim pesan:
   ```
   POST /api/wa/kirim-test
   { "nomor": "08123456789", "pesan": "Tes dari ISP App" }
   ```

4. Trigger notifikasi gangguan (bisa ke banyak pelanggan sekaligus):
   ```
   POST /api/wa/notifikasi/gangguan
   { "pelangganIds": ["id1", "id2"], "keterangan": "Gangguan fiber optik di area Blimbing, estimasi selesai 2 jam" }
   ```

5. Pengingat jatuh tempo jalan **otomatis tiap hari jam 09:00** (cron), cek tagihan yang jatuh tempo dalam 3 hari. Bisa juga dites manual: `POST /api/wa/notifikasi/jatuh-tempo`

6. Struk pembayaran (`notifikasiService.kirimStrukPembayaran(tagihanId)`) akan dipanggil otomatis dari webhook payment gateway di modul berikutnya.

7. Riwayat semua notifikasi yang terkirim/gagal: `GET /api/wa/log`

## Modul Payment Gateway (sudah jadi — Midtrans)

1. Daftar akun di [dashboard.midtrans.com](https://dashboard.midtrans.com) (mode Sandbox dulu untuk testing, gratis).
2. Ambil **Server Key** dan **Client Key** dari Settings > Access Keys, isi ke `.env`.
3. Di dashboard Midtrans, set **Payment Notification URL** ke:
   ```
   https://domain-vps-kamu.com/api/payment/webhook
   ```
   (waktu masih di lokal/testing, pakai tool seperti ngrok supaya Midtrans bisa akses webhook kamu)

**Alur pembayaran:**
- `POST /api/payment/tagihan/:tagihanId/bayar` (admin/penagih/pelanggan) → dapat `redirectUrl` untuk dibuka pelanggan, berisi pilihan VA/QRIS/e-wallet
- Setelah pelanggan bayar, Midtrans otomatis kirim notifikasi ke `/api/payment/webhook` → status tagihan berubah jadi LUNAS → struk WA otomatis terkirim
- Untuk pembayaran tunai/transfer langsung yang dicatat penagih di lapangan: `POST /api/payment/tagihan/:tagihanId/bayar-manual` (admin/penagih) → langsung LUNAS + kirim struk WA

Signature webhook diverifikasi otomatis (SHA512) supaya tidak bisa dipalsukan orang luar.

## Modul berikutnya (belum diimplementasi)
- Integrasi OLT (redaman, via SNMP/SSH tergantung merek) — menyusul setelah merek dipastikan
